import sys
import threading
from brain.high import HighLevelController

class AIInterface:
    """
    ai.py
    Translates CLI commands into Ollama AI prompts or directly applies actions via high.py
    """
    def __init__(self, high_level):
        self.high = high_level
        self.running = True
        
    def start_cli(self):
        print("--- Stickman AI CLI Started ---")
        print("Direct commands: 'walk_right', 'walk_left', 'jump', 'crouch', 'stop'")
        print("Type 'exit' to quit AI CLI.")
        
        while self.running:
            try:
                cmd = input("Stickman> ").strip()
                if cmd == "exit":
                    self.running = False
                    break
                elif cmd == "stop":
                    self.high.stop()
                elif cmd in ["walk_right", "walk_left", "jump", "crouch"]:
                    self.high.execute_action(cmd)
                else:
                    print("AI parsing via Ollama not yet active. Use direct commands.")
            except (EOFError, KeyboardInterrupt):
                self.running = False
                break
                
    def run_in_background(self):
        t = threading.Thread(target=self.start_cli)
        t.daemon = True
        t.start()
        return t
