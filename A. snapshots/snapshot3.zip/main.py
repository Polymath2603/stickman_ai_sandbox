import pygame
import sys
from sandbox import Sandbox
from body import Body
from brain.low import LowLevelController
from brain.high import HighLevelController
from brain.idle import IdleController

import argparse
from utils.reporter import Reporter

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", type=str, help="Action to test headlessly")
    parser.add_argument("--frames", type=int, default=120, help="Frames to test")
    parser.add_argument("--demo", action="store_true", help="Run automated visual demo")
    args = parser.parse_args()

    sandbox = Sandbox()
    
    # Starting ragdoll position
    start_pos = (sandbox.s2w((600, 400))[0], 0.2)
    stickman = Body(sandbox.world, position=start_pos)
    
    # Brains
    low = LowLevelController(stickman)
    high = HighLevelController(stickman)
    idle = IdleController(stickman, low)

    active_keys = set()
    frames_simulated = 0

    running = True
    while running:
        if args.test:
            # Headless Test Mode
            if args.test != "idle":
                if high.current_action is None or type(high.current_action).__name__ != f"{args.test.capitalize()}Action":
                    high.execute_action(args.test) 
            
            # Print frame report
            print(f"--- FRAME {frames_simulated} ---")
            Reporter.print_diagnostics(stickman)

            frames_simulated += 1
            if frames_simulated >= args.frames:
                break
                
            # Force close window events for safety
            pygame.event.get()
        else:
            if args.demo:
                current_time = pygame.time.get_ticks()
                if 1000 < current_time < 4000:
                    active_keys.add(pygame.K_RIGHT)
                elif 4000 <= current_time < 5000:
                    if pygame.K_RIGHT in active_keys: active_keys.remove(pygame.K_RIGHT)
                elif 5000 <= current_time < 6000:
                    active_keys.add(pygame.K_UP)
                elif 6000 <= current_time < 6500:
                    if pygame.K_UP in active_keys: active_keys.remove(pygame.K_UP)
                if current_time > 10000:
                    running = False

            # Interactive Mode
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                sandbox.handle_mouse_events(event)
                
                if event.type == pygame.KEYDOWN:
                    active_keys.add(event.key)
                    if event.key == pygame.K_q:
                        running = False
                    elif event.key == pygame.K_r:
                        for b in stickman.bodies.values():
                            sandbox.world.DestroyBody(b)
                        stickman.bodies.clear()
                        stickman.joints.clear()
                        stickman.create_ragdoll(start_pos=start_pos)
                        active_keys.clear()
                        high.stop()
                    elif event.key == pygame.K_SPACE:
                        idle.toggle()

                if event.type == pygame.KEYUP:
                    if event.key in active_keys:
                        active_keys.remove(event.key)

            if pygame.K_RIGHT in active_keys:
                if high.current_action is None or type(high.current_action).__name__ != "Walk_rightAction":
                    high.execute_action("walk_right")
            elif pygame.K_LEFT in active_keys:
                if high.current_action is None or type(high.current_action).__name__ != "Walk_leftAction":
                    high.execute_action("walk_left")
            elif pygame.K_UP in active_keys:
                if high.current_action is None or type(high.current_action).__name__ != "JumpAction":
                    high.execute_action("jump")
            elif pygame.K_DOWN in active_keys:
                if high.current_action is None or type(high.current_action).__name__ != "CrouchAction":
                    high.execute_action("crouch")
            else:
                high.stop() 

        # Update controllers (Idle provides base posture, Action overrides specific joints)
        is_action_active = (high.current_action is not None)
        is_mouse_active = (sandbox.mouse_joint is not None)
        idle.update(is_action_active=is_action_active, is_mouse_active=is_mouse_active)
        high.step() 
        
        # Step physics
        sandbox.step()
        
        if not args.test:
            sandbox.render()
            if sandbox.clock.get_time() > 0 and pygame.time.get_ticks() % 500 < 50:
                 Reporter.print_diagnostics(stickman)

            hud = sandbox.font.render(f"Balance: {'ON' if idle.is_active else 'OFF'} | High: {type(high.current_action).__name__ if high.current_action else 'None'}", True, (255, 255, 255))
            sandbox.screen.blit(hud, (10, 10))
            pygame.display.flip()
            sandbox.clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
