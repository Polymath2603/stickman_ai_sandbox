class JumpAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        if self.ticks < 15:
            # Phase 1: Squat down
            self.low.set_target_angle("l_hip", 1.0, max_torque=800, max_speed=5.0)
            self.low.set_target_angle("r_hip", 1.0, max_torque=800, max_speed=5.0)
            self.low.set_target_angle("l_knee", -2.0, max_torque=800, max_speed=5.0)
            self.low.set_target_angle("r_knee", -2.0, max_torque=800, max_speed=5.0)
            self.low.set_target_angle("l_ankle", 1.0, max_torque=400, max_speed=5.0)
            self.low.set_target_angle("r_ankle", 1.0, max_torque=400, max_speed=5.0)
            
            # Arms back
            self.low.set_target_angle("l_shoulder", 1.0, max_torque=200)
            self.low.set_target_angle("r_shoulder", 1.0, max_torque=200)
        elif self.ticks < 30:
            # Phase 2: Explosive extend
            if self.ticks == 15:
                # Apply jumping impulse directly to the mass to prevent joint-snapping!
                torso = self.stickman.bodies["torso"]
                torso.ApplyLinearImpulse((0.0, 250.0), torso.worldCenter, True)
                
            self.low.set_target_angle("l_hip", -0.2, max_torque=800, max_speed=15.0)
            self.low.set_target_angle("r_hip", -0.2, max_torque=800, max_speed=15.0)
            self.low.set_target_angle("l_knee", 0.0, max_torque=800, max_speed=15.0)
            self.low.set_target_angle("r_knee", 0.0, max_torque=800, max_speed=15.0)
            self.low.set_target_angle("l_ankle", -0.5, max_torque=500, max_speed=15.0)
            self.low.set_target_angle("r_ankle", -0.5, max_torque=500, max_speed=15.0)
            
            # Arms swing up natively
            self.low.set_target_angle("l_shoulder", -2.0, max_torque=400, max_speed=15.0)
            self.low.set_target_angle("r_shoulder", -2.0, max_torque=400, max_speed=15.0)
        else:
            # Fall naturally
            self.low.relax_all()

    def is_finished(self):
        return self.ticks > 60
