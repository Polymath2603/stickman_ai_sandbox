class JumpAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        if self.ticks < 15:
            # Phase 1: Squat down
            self.low.set_target_angle("l_hip", 1.0, max_torque=800)
            self.low.set_target_angle("r_hip", 1.0, max_torque=800)
            self.low.set_target_angle("l_knee", -2.0, max_torque=800)
            self.low.set_target_angle("r_knee", -2.0, max_torque=800)
            self.low.set_target_angle("l_ankle", 1.0, max_torque=400)
            self.low.set_target_angle("r_ankle", 1.0, max_torque=400)
            
            # Arms back
            self.low.set_target_angle("l_shoulder", 1.0)
            self.low.set_target_angle("r_shoulder", 1.0)
        elif self.ticks < 30:
            # Phase 2: Explosive extend
            self.low.set_target_angle("l_hip", -0.2, max_torque=2000)
            self.low.set_target_angle("r_hip", -0.2, max_torque=2000)
            self.low.set_target_angle("l_knee", 0.0, max_torque=2000)
            self.low.set_target_angle("r_knee", 0.0, max_torque=2000)
            self.low.set_target_angle("l_ankle", -0.5, max_torque=1000)
            self.low.set_target_angle("r_ankle", -0.5, max_torque=1000)
            
            # Arms up
            self.low.set_target_angle("l_shoulder", -2.0, max_torque=1000)
            self.low.set_target_angle("r_shoulder", -2.0, max_torque=1000)
        else:
            # Fall naturally
            self.low.relax_all()

    def is_finished(self):
        return self.ticks > 60
