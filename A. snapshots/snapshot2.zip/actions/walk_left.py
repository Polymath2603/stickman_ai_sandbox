import math

class Walk_leftAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        # Walking speed
        cycle = self.ticks * 0.15 
        
        # Lean backward/left into the walk
        self.low.set_target_angle("l_ankle", -0.1, max_torque=200)
        self.low.set_target_angle("r_ankle", -0.1, max_torque=200)
        
        # Opposite cycle sign for left logic? Just offset arms/hips differently 
        # or use same cycle but let Physics carry moving momentum naturally.
        r_hip_angle = math.sin(cycle) * 0.6
        l_hip_angle = math.sin(cycle + math.pi) * 0.6 
        
        # Knees still bend negative (only physical direction valid)
        r_knee_angle = -0.6 + math.cos(cycle + math.pi) * 0.6 
        l_knee_angle = -0.6 + math.cos(cycle) * 0.6
        
        self.low.set_target_angle("r_hip", r_hip_angle, max_torque=400)
        self.low.set_target_angle("l_hip", l_hip_angle, max_torque=400)
        
        self.low.set_target_angle("r_knee", r_knee_angle, max_torque=200)
        self.low.set_target_angle("l_knee", l_knee_angle, max_torque=200)
        
        self.low.set_target_angle("r_shoulder", math.sin(cycle + math.pi) * 0.5, max_torque=150)
        self.low.set_target_angle("l_shoulder", math.sin(cycle) * 0.5, max_torque=150)

    def is_finished(self):
        return False
