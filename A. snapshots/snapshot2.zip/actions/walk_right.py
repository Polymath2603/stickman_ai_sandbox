import math

class Walk_rightAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        # Walking speed
        cycle = self.ticks * 0.15 
        
        # Ankles stay slightly tilted to lean forward into the walk
        self.low.set_target_angle("l_ankle", 0.1, max_torque=100, max_speed=2.0)
        self.low.set_target_angle("r_ankle", 0.1, max_torque=100, max_speed=2.0)
        
        # Hips swing opposite each other smoothly
        r_hip_angle = math.sin(cycle) * 0.6
        l_hip_angle = math.sin(cycle + math.pi) * 0.6 
        
        # Knees bend (negative) when lifting leg to swing forward
        r_knee_angle = -0.6 + math.cos(cycle) * 0.6 # Cosine creates lift during forward swing
        l_knee_angle = -0.6 + math.cos(cycle + math.pi) * 0.6
        
        self.low.set_target_angle("r_hip", r_hip_angle, max_torque=150, max_speed=3.0)
        self.low.set_target_angle("l_hip", l_hip_angle, max_torque=150, max_speed=3.0)
        
        self.low.set_target_angle("r_knee", r_knee_angle, max_torque=100, max_speed=3.0)
        self.low.set_target_angle("l_knee", l_knee_angle, max_torque=100, max_speed=3.0)
        
        # Arms swing naturally opposite to legs
        self.low.set_target_angle("r_shoulder", math.sin(cycle + math.pi) * 0.5, max_torque=50)
        self.low.set_target_angle("l_shoulder", math.sin(cycle) * 0.5, max_torque=50)

    def is_finished(self):
        return False
