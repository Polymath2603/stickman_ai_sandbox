from brain.low import LowLevelController
from utils import config
import math

class IdleController:
    """
    brain/idle.py
    Parallel balance controller. Tries to maintain upright posture continuously.
    Works cooperatively with high.py (doesn't overwrite active joints arbitrarily, or combines softly).
    """
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.is_active = True

    def toggle(self):
        self.is_active = not self.is_active
        if not self.is_active:
            self.low.relax_all()

    def update(self):
        if not self.is_active:
            return
            
        torso = self.stickman.bodies["torso"]
        # Basic upright standing PID
        target_angle = 0.0
        # Calculate Center of Mass (CoM) vs Support Base (approx mid-ankles)
        l_foot = self.stickman.bodies["l_foot"].position.x
        r_foot = self.stickman.bodies["r_foot"].position.x
        support_center = (l_foot + r_foot) / 2.0
        
        com_x = torso.position.x
        error_x = com_x - support_center
        
        # 1. Apply 'invisible' core stability torque to Torso to keep it upright
        # This acts as a gentle gyroscope, yielding to heavy impacts rather than freezing identically
        upright_error = 0.0 - torso.angle
        torso.ApplyAngularImpulse(upright_error * 50.0 - torso.angularVelocity * 5.0, True)

        # 2. Use the CoM error to calculate a desired ankle lean to keep feet under CoM
        target_angle = max(-0.4, min(0.4, error_x * 0.5)) 
        
        # 3. Soften the leg joints significantly to allow natural yielding to gravity/mouse
        # Ankles
        self.low.set_target_angle("l_ankle", target_angle, max_torque=300.0, kp=15.0)
        self.low.set_target_angle("r_ankle", target_angle, max_torque=300.0, kp=15.0)
        
        # Knees
        self.low.set_target_angle("l_knee", 0.0, max_torque=400.0, kp=15.0)
        self.low.set_target_angle("r_knee", 0.0, max_torque=400.0, kp=15.0)
        
        # Hips (Counter-tilt slightly if legs lean)
        self.low.set_target_angle("l_hip", -target_angle * 0.5, max_torque=400.0, kp=15.0)
        self.low.set_target_angle("r_hip", -target_angle * 0.5, max_torque=400.0, kp=15.0)
        
        # Relaxed arms balance
        self.low.set_target_angle("l_shoulder", 0.1, max_torque=150.0, kp=10.0)
        self.low.set_target_angle("r_shoulder", -0.1, max_torque=150.0, kp=10.0)
        self.low.set_target_angle("l_elbow", 0.1, max_torque=100.0, kp=10.0)
        self.low.set_target_angle("r_elbow", -0.1, max_torque=100.0, kp=10.0)
        
        self.low.set_target_angle("neck", 0.0, max_torque=150.0, kp=15.0)
