class Walk_leftAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.phase = 0
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        phase_duration = 20
        self.phase = (self.ticks // phase_duration) % 2
        
        # Lean slightly left
        self.low.set_target_angle("l_ankle", -0.2)
        self.low.set_target_angle("r_ankle", -0.2)
        
        if self.phase == 0:
            self.low.set_target_angle("l_hip", -0.5, max_torque=400)
            self.low.set_target_angle("l_knee", 0.0, max_torque=300)
            
            self.low.set_target_angle("r_hip", 0.5, max_torque=400)
            self.low.set_target_angle("r_knee", -0.5, max_torque=300)
            
            self.low.set_target_angle("l_shoulder", 0.5)
            self.low.set_target_angle("r_shoulder", -0.5)
        else:
            self.low.set_target_angle("r_hip", -0.5, max_torque=400)
            self.low.set_target_angle("r_knee", 0.0, max_torque=300)
            
            self.low.set_target_angle("l_hip", 0.5, max_torque=400)
            self.low.set_target_angle("l_knee", -0.5, max_torque=300)
            
            self.low.set_target_angle("r_shoulder", 0.5)
            self.low.set_target_angle("l_shoulder", -0.5)

    def is_finished(self):
        return False
