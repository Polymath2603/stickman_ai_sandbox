class Walk_rightAction:
    def __init__(self, stickman, low_level):
        self.stickman = stickman
        self.low = low_level
        self.phase = 0
        self.ticks = 0

    def step(self):
        self.ticks += 1
        
        # Simple alternating gait for walking right
        phase_duration = 20
        self.phase = (self.ticks // phase_duration) % 2
        
        # Lean forward slightly
        self.low.set_target_angle("l_ankle", 0.2)
        self.low.set_target_angle("r_ankle", 0.2)
        
        if self.phase == 0:
            # Right leg forward, left leg back
            self.low.set_target_angle("r_hip", 0.5, max_torque=400)
            self.low.set_target_angle("r_knee", 0.0, max_torque=300)
            
            self.low.set_target_angle("l_hip", -0.5, max_torque=400)
            self.low.set_target_angle("l_knee", -0.5, max_torque=300)
            
            # Arms swing opposite
            self.low.set_target_angle("r_shoulder", -0.5)
            self.low.set_target_angle("l_shoulder", 0.5)
        else:
            # Left leg forward, right leg back
            self.low.set_target_angle("l_hip", 0.5, max_torque=400)
            self.low.set_target_angle("l_knee", 0.0, max_torque=300)
            
            self.low.set_target_angle("r_hip", -0.5, max_torque=400)
            self.low.set_target_angle("r_knee", -0.5, max_torque=300)
            
            self.low.set_target_angle("l_shoulder", -0.5)
            self.low.set_target_angle("r_shoulder", 0.5)

    def is_finished(self):
        return False # Continuous action until stopped by HighLevelController or new action
