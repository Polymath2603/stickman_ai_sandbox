import pygame
import sys
from sandbox import Sandbox
from body import Body
from brain.low import LowLevelController
from brain.high import HighLevelController
from brain.idle import IdleController

def main():
    sandbox = Sandbox()
    
    # Starting ragdoll position
    start_pos = (sandbox.s2w((600, 400))[0], 0.2)
    stickman = Body(sandbox.world, position=start_pos)
    
    # Brains
    low = LowLevelController(stickman)
    high = HighLevelController(stickman)
    idle = IdleController(stickman, low)

    active_keys = set()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            sandbox.handle_mouse_events(event)
            
            if event.type == pygame.KEYDOWN:
                active_keys.add(event.key)
                if event.key == pygame.K_q:
                    running = False
                elif event.key == pygame.K_r:
                    # Reset
                    for b in stickman.bodies.values():
                        sandbox.world.DestroyBody(b)
                    stickman.bodies.clear()
                    stickman.joints.clear()
                    stickman.create_ragdoll(start_pos=start_pos)
                    active_keys.clear()
                    high.stop()
                elif event.key == pygame.K_SPACE:
                    idle.toggle()

            if event.type == pygame.KEYUP:
                if event.key in active_keys:
                    active_keys.remove(event.key)

        # Map active keys to continuous action
        if pygame.K_RIGHT in active_keys:
            if high.current_action is None or type(high.current_action).__name__ != "Walk_rightAction":
                high.execute_action("walk_right")
        elif pygame.K_LEFT in active_keys:
            if high.current_action is None or type(high.current_action).__name__ != "Walk_leftAction":
                high.execute_action("walk_left")
        elif pygame.K_UP in active_keys:
            if high.current_action is None or type(high.current_action).__name__ != "JumpAction":
                high.execute_action("jump")
        elif pygame.K_DOWN in active_keys:
            if high.current_action is None or type(high.current_action).__name__ != "CrouchAction":
                high.execute_action("crouch")
        else:
            high.stop() # No movement keys held

        # Run systems
        # Step high level (actions override idle optionally)
        high.step()
        
        # Run parallel idle (balance daemon) if no strictly overriding actions are freezing joints
        if high.current_action is None:
            idle.step()

        sandbox.step()
        sandbox.render()
        
        # --- AI Diagnostic Report (Print every 30 frames) ---
        if sandbox.clock.get_time() > 0 and pygame.time.get_ticks() % 500 < 50: # Roughly twice a second
             torso = stickman.bodies["torso"]
             l_foot = stickman.bodies["l_foot"]
             r_foot = stickman.bodies["r_foot"]
             
             print(f"--- DIAGNOSTIC REPORT (COM vs Feet) ---")
             print(f"Torso: x={torso.position.x:.2f}, y={torso.position.y:.2f}, ang={torso.angle:.2f}")
             print(f"L_Foot: x={l_foot.position.x:.2f}, y={l_foot.position.y:.2f}, ang={l_foot.angle:.2f}")
             print(f"R_Foot: x={r_foot.position.x:.2f}, y={r_foot.position.y:.2f}, ang={r_foot.angle:.2f}")
             
             print("Joint Angles:")
             for j_name, joint in stickman.joints.items():
                 # For revolute joint, angle is bodyB.angle - bodyA.angle roughly, but joint.angle is exact
                 print(f"  {j_name}: {joint.angle:.2f}")

        # HUD
        hud = sandbox.font.render(f"Balance: {'ON' if idle.is_active else 'OFF'} | High: {type(high.current_action).__name__ if high.current_action else 'None'}", True, (255, 255, 255))
        sandbox.screen.blit(hud, (10, 10))
        
        pygame.display.flip()
        sandbox.clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
